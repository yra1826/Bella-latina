# BellaLatina.ai - Backend MVP (Render + Stripe)

Este paquete contiene el backend MVP listo para desplegar en **Render** (Postgres) y conectar con **Stripe**.
Incluye código básico (Node.js + Express), scripts de ejemplo para fulfillment, y SQL inicial con 2 productos de prueba.

## Contenido del ZIP
- `package.json`
- `src/` (server, rutas, servicios)
- `sql/init.sql` (tablas + productos de prueba)
- `.env.example` (variables de entorno)
- `README.md` (este archivo)

## Variables de entorno (configurar en Render)
Copia las variables en Render → Environment → Environment Variables:

- `DATABASE_URL` = URL de Postgres (Render lo crea y la provee)
- `STRIPE_SECRET_KEY` = tu clave secreta Stripe
- `STRIPE_WEBHOOK_SECRET` = (opcional) secreto del webhook Stripe
- `PORT` = 10000 (o dejar vacío para usar default)
- `NODE_ENV` = production
- `EMAIL_FROM` = bellalatina.store@gmail.com

> **Nota:** Elegiste Render para la base de datos y Stripe para pagos. A continuación los pasos rápidos.

## Pasos para desplegar en Render (rápido)
1. Crea una cuenta en https://render.com y crea un **Web Service** desde tu repo (sube el ZIP a GitHub o conecta repo).
2. Añade una **Managed Postgres** en Render; copia la `DATABASE_URL` a las Environment Variables del Web Service.
3. En Environment Variables añade `STRIPE_SECRET_KEY` con la clave de Stripe.
4. Comando build: `npm install`
5. Start Command: `npm start`
6. Importa `sql/init.sql` en la base de datos (puedes usar psql o el panel de Render).

## Ejecutar localmente (desarrollo)
1. Instala dependencias: `npm install`
2. Crea archivo `.env` basado en `.env.example`
3. Ejecuta: `npm run dev`

## Endpoints principales
- `GET /api/products` — lista productos
- `GET /api/products/:id` — producto
- `POST /api/orders` — crear pedido (mock payment + fulfillment)
- `POST /api/webhooks/dropshipper` — webhook de proveedor (simulado)
- `POST /api/webhooks/stripe` — webhook de Stripe (ejemplo)

## Siguientes recomendaciones
- Conectar proveedor real: Spocket/Printful/AliExpress y mapear `provider_sku`.
- Implementar cola de procesamiento (BullMQ/Redis) para workers de fulfillment.
- Implementar verificación de firma en Stripe webhook.
- Preparar el frontend (app Ionic/React) y conectar Checkout con Stripe.

Si quieres, ahora puedo:
- Generar el ZIP (listo) y el `.env` final configurado para Render (con placeholders).
- Preparar el script para levantar la base de datos en Render (comandos psql).
- Pasar a la **Campaña B** y generar los creativos finales y JSON listo para Meta Ads API.

¡Listo para el siguiente paso, Yeison!
