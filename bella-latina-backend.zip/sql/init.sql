CREATE TABLE IF NOT EXISTS products (
  id SERIAL PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  price NUMERIC(10,2),
  image_url TEXT,
  provider_sku TEXT,
  featured BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS orders (
  id SERIAL PRIMARY KEY,
  customer_name TEXT,
  customer_email TEXT,
  total NUMERIC(10,2),
  status TEXT,
  tracking TEXT,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS order_items (
  id SERIAL PRIMARY KEY,
  order_id INTEGER REFERENCES orders(id),
  product_id INTEGER REFERENCES products(id),
  qty INTEGER,
  price NUMERIC(10,2)
);

INSERT INTO products (title, description, price, image_url, provider_sku, featured)
VALUES
('Sérum Revitalizante - BellaLatina', 'Sérum con extracto de aguacate para piel radiante', 24.99, 'https://example.com/images/serum.jpg', 'SKU-SERUM-01', true),
('Paleta de Iluminadores - Edición Latina', 'Iluminadores con tonos cálidos', 18.50, 'https://example.com/images/paleta.jpg', 'SKU-PALETA-01', true)
ON CONFLICT DO NOTHING;
