const pool = require('../db/pool');
const dropshipper = require('./dropshipper');

async function processPending() {
  const res = await pool.query("SELECT * FROM orders WHERE status='processing' LIMIT 10");
  for (const order of res.rows) {
    const items = (await pool.query('SELECT * FROM order_items WHERE order_id=$1',[order.id])).rows;
    const fulfillment = await dropshipper.createOrder(order.id, items, { name: order.customer_name, email: order.customer_email });
    await pool.query('UPDATE orders SET status=$1 WHERE id=$2', ['fulfilled', order.id]);
  }
}

processPending();
