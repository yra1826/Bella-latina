const axios = require('axios');

async function createOrder(orderId, items, customer) {
  // MOCK: enviar petición al API del proveedor
  const mock = {
    provider_order_id: `PROV-${Date.now()}`,
    status: 'created',
    tracking: null
  };
  return mock;
}

module.exports = { createOrder };
