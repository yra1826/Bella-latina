const Stripe = require('stripe');
const stripe = Stripe(process.env.STRIPE_SECRET_KEY);

async function createPaymentIntent(amount, customer) {
  const intent = await stripe.paymentIntents.create({
    amount: Math.round(amount * 100),
    currency: 'usd',
    receipt_email: customer.email,
    metadata: { customer_name: customer.name }
  });
  return intent;
}

module.exports = { createPaymentIntent };
