const express = require('express');
const pool = require('../db/pool');
const dropshipper = require('../services/dropshipper');
const payments = require('../services/payments');
const router = express.Router();

// POST /api/orders  (crea pedido local y lanza fulfillment)
router.post('/', async (req, res) => {
  try {
    const { customer, items, paymentMethod } = req.body;
    const total = items.reduce((s, it) => s + it.price * it.qty, 0);

    const { rows } = await pool.query(
      'INSERT INTO orders(customer_name, customer_email, total, status) VALUES($1,$2,$3,$4) RETURNING *',
      [customer.name, customer.email, total, 'created']
    );
    const order = rows[0];

    for (const it of items) {
      await pool.query(
        'INSERT INTO order_items(order_id, product_id, qty, price) VALUES($1,$2,$3,$4)',
        [order.id, it.product_id, it.qty, it.price]
      );
    }

    // crear PaymentIntent con Stripe
    const payment = await payments.createPaymentIntent(total, customer);

    // mandar fulfillment al dropshipper (mock)
    const fulfillment = await dropshipper.createOrder(order.id, items, customer);

    await pool.query('UPDATE orders SET status=$1 WHERE id=$2', ['processing', order.id]);

    res.json({ order, payment, fulfillment });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'failed' });
  }
});

module.exports = router;
