const express = require('express');
const router = express.Router();
const pool = require('../db/pool');

// Webhook ejemplo: proveedor notifica envío
router.post('/dropshipper', async (req, res) => {
  try {
    const { order_id, tracking, status } = req.body;
    await pool.query('UPDATE orders SET status=$1, tracking=$2 WHERE id=$3', [status, tracking, order_id]);
    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ ok: false });
  }
});

// Stripe webhook example (raw body recommended in production)
router.post('/stripe', express.raw({type: 'application/json'}), async (req, res) => {
  // manejar evento de pago (verificar firma en producción)
  res.json({ received: true });
});

module.exports = router;
